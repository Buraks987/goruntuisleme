import cv2
from matplotlib import pyplot as plt
import numpy as np


resim = cv2.imread("motor.jpg")
cv2.imshow("motor",resim)
cv2.waitKey(0)
inverted = np.invert(resim)
cv2.imshow("Resmin asil hali",resim)
cv2.imshow("Resmin inverted hali",inverted)
cv2.waitKey()
sonhali = 255 - resim
cv2.imshow("son hali",sonhali)
cv2.waitKey()
[h,w] = resim.shape
new_image = np.zeros([h,w], dtype=np.uint8)
for x in range(h):
     for y in range(w):
      new_image[x,y] = 255 - resim[x,y]

print(resim[0,0])
cv2.imshow("Manuel_inverted",new_image)

